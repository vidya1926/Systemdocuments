package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	// public static ChromeDriver driver;
	private static final ThreadLocal<ChromeDriver> tldriver = new ThreadLocal<ChromeDriver>();

	public void setDriver() {
		tldriver.set(new ChromeDriver());
	}

	public ChromeDriver getDriver() {
		/*
		 * ChromeDriver chromeDriver = tldriver.get(); return chromeDriver;
		 */
		return tldriver.get();
	}

	public String filename;
	public int sheetIndex;
	public static ExtentReports extent;
	public String testcaseName,testDesc,author,category;
	public static ExtentTest test ,node;
	
	@Parameters({ "url" })
	@BeforeMethod
	public void preCondition(String url) {
		// driver = new ChromeDriver();
		node = test.createNode(testcaseName);
		setDriver();
		getDriver().get(url);
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(ConfigurationManager.configuration().getPause()));
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	@DataProvider
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcel.readData(filename, sheetIndex);
		return data;
	}
	
	
	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/extentReport.html");
		reporter.setAppendExisting(true);
		extent=new ExtentReports();		
		extent.attachReporter(reporter);
	}
	
	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testcaseName,testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}
	
	
	public void reportStep(String status,String message) throws IOException {
		if(status.equalsIgnoreCase("pass")) {
			node.pass(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic"+takesnap()+".jpg").build());
		}else if(status.equalsIgnoreCase("fail")) {
			node.fail(message,MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic"+takesnap()+".jpg").build());
		}
		
	}	
	
	public int takesnap() throws IOException {
		int random =(int)( Math.random()*9999);
		File screenshot = getDriver().getScreenshotAs(OutputType.FILE);
		File destn=new File("./snap/pic"+random+".jpg");
		FileUtils.copyFile(screenshot,destn);
		return random;
	}
	
	
	
	@AfterSuite
	public void endReport() {
		extent.flush();
	}
	
	
	
	
	
	

}
