package testcase;

import org.testng.annotations.BeforeTest;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = { "src/main/java/features/Login.feature" }, glue = "pages", monochrome = true)
public class Runner extends ProjectSpecificMethod {

	@BeforeTest
	public void setValues() {
		testcaseName = "Login funtionality";
		testDesc = "Login with positive credentials";
		author = "Sumitha";
		category = "Funtional testing";

	}
}
