package base;

import org.aeonbits.owner.Config;
import org.aeonbits.owner.Config.LoadPolicy;
import org.aeonbits.owner.Config.LoadType;

@LoadPolicy(LoadType.MERGE)
@Config.Sources({//TO set the properties file path from where the data to be read
    "system:properties",   
    "classpath:config.properties",
       })

public interface Configuration extends Config {
	
	//abstract methods using Key to read data
	
	@Key("pause")
	int getPause();
	
	@Key("username")
	String getUserName();
	
	@Key("password")
	String getPassword();
	 
}

