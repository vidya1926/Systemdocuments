package base;

public class AccessingPrivateVariable extends LearnEncapsulation {
	
	
	public static void main(String[] args) {
		AccessingPrivateVariable pv=new AccessingPrivateVariable();		
		System.out.println(pv.getPwd());
		pv.setPwd(567);
		System.out.println(pv.getPwd());
	}
}
