package base;

public class LearnEncapsulation {
	
	
	private int pwd=123;

	public void setPwd(int pwd) {
		this.pwd = pwd;
	}

	public int getPwd() {
		return pwd;
	}
	
	

}
