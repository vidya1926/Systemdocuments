package base;

public class LearnCompileTimeException {

	
	public static void add(int a, int b) throws InterruptedException {
		if(a>b) {
			Thread.sleep(4000);
			System.out.println(a-b);
		}else {
			throw new RuntimeException("Check your input ,a should always >b");
		}
	}
	
	public static void main(String[] args) throws InterruptedException  {

		try {
		add(3,9);
		}catch(Exception e){
		   add(9,3);
		}finally {
		System.out.println("End of Program");
	}
	}
}
