package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {

		//Step:1  physical file ->created manually under the project
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/extentReport.html");
		
		//to have history 
		reporter.setAppendExisting(true);
		//Step:2 ExtentReport -->attach the report to the physical
		ExtentReports extent=new ExtentReports();		
		extent.attachReporter(reporter);
		
		//to log the testcase details
		ExtentTest test = extent.createTest("CreateLead funtionality" ,"CreateLead with mandatory fields");
		test.assignAuthor("Sumitha");
		test.assignCategory("Funtional testing");
		
		test.pass("Logged in to the application succesfully");
		test.fail("Login was not successful",MediaEntityBuilder.createScreenCaptureFromPath(".././snap/pic.png").build());
		
		//manadatory step
		extent.flush(); //write into the report.html
		
		
		
	}

}
