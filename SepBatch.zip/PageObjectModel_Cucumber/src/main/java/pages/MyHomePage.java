package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod{
	
	/*
	 * public MyHomePage() { this.driver=driver; }
	 */
	public LeadsPage clickLeads() throws IOException {
		try {
			getDriver().findElement(By.linkText("Leads")).click();
			reportStep("pass", "Leads is clicked successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			reportStep("fail", "Leads is not clicked successfully");
		}
		return new LeadsPage();
	}
	
	/*
	 * public AccountsPage clickAccounts() {
	 * driver.findElement(By.linkText("Leads")).click(); return new AccountsPage();
	 * }
	 */

}
