package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod {
	/*
	 * public WelcomePage(ChromeDriver driver) { this.driver = driver; }
	 */

	@Then("WelcomePage is displayed")
	public WelcomePage verifyWelcomePage() throws IOException {
		try {
			System.out.println(getDriver().getTitle());
			reportStep("pass", "WelcomePage is Verified successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			reportStep("fail", "Landing is not in right page");

		}

		return this;
	}

	public MyHomePage clickCrmsfa() throws IOException {

		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("pass", "crmsfa is clicked successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			reportStep("fail", "crmsfa is not clicked successfully");		}

		return new MyHomePage();
	}

	public LoginPage clickLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}

}
