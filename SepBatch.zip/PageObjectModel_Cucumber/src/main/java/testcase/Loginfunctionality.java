package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Loginfunctionality extends ProjectSpecificMethod {

	@BeforeTest
	public void setValues() {
		testcaseName = "Login funtionality";
		testDesc = "Login with positive credentials";
		author = "Sumitha";
		category = "Funtional testing";

	}

	@Test
	public void runLogin() throws IOException {

		System.out.println(getDriver() + "for the thread value" + Thread.currentThread().getId());

		new LoginPage().enterUsername().enterPassword().clickLogin().clickCrmsfa();

	}

}
