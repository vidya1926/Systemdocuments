package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateLeadFuntionality extends ProjectSpecificMethod{
	
	
		
	@Test(dataProvider="sendData")
	public void runCreate(String cname,String fname,String lname) throws IOException {
		System.out.println(getDriver() +"for the thread value" +Thread.currentThread().getId());
		new LoginPage().enterUsername().enterPassword().clickLogin().clickCrmsfa()
		.clickLeads().clickcreateLead().enterCompanyName(cname).enterFirstName(fname).enterLastName(lname).clickCreate().verifyCreateLead();
		
	}
	
	@BeforeTest
	public void setValues() {
		filename="Leads";
		sheetIndex=0;
		testcaseName="CreateLead funtionality";
		testDesc="CreateLead with mandatory fields";
		author="Nagalingam";
		category="Regression testing";
	
		
	}

}
