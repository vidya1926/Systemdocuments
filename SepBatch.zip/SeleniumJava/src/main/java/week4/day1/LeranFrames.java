package week4.day1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LeranFrames {

	public static void main(String[] args) {
		ChromeDriver driver = new ChromeDriver();
		// driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();

		driver.get("https://www.leafground.com/waits.xhtml");

		driver.findElement(By.xpath("//span[text()='Click']")).click();

	
		// synatx
		WebDriverWait wb = new WebDriverWait(driver, Duration.ofSeconds(20));
		wb.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='I am here']")));
		WebElement visibil = driver.findElement(By.xpath("//span[text()='I am here']"));
		String text = visibil.getText();
		System.out.println(text);
		
		driver.findElement(By.xpath("(//span[text()='Click'])[3]")).click();
		wb.until(ExpectedConditions.textToBe(By.xpath("//span[text()='Did you notice?']"), "Did you notice?"));
		WebElement textto = driver.findElement(By.xpath("//span[text()='Did you notice?']"));
		System.out.println(textto.getText());
	}
	

}
