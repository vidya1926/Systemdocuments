package week3.day2;

public class ICICI extends AxisBank implements RBI,CIBILScore{

	public static void main(String[] args) {
		AxisBank obj=new ICICI();	
		obj.issuingCard();
	}

	public void issuingCard() {
	System.out.println("Card is issued");
	}

	public void transaction() {
		// TODO Auto-generated method stub
		
	}

	public void kycDocument() {
		// TODO Auto-generated method stub
		
	}

	public void rateOfInterest() {
		// TODO Auto-generated method stub
		
	}

	public void cibilScore() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void activateTraction() {
		// TODO Auto-generated method stub
		
	}

}
