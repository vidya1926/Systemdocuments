package week3.day2;

public abstract class AxisBank implements RBI,CIBILScore {

	public abstract void activateTraction();	
	
	public void loanDetails() {
		
	}

	



	

}
