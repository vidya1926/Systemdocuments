package week3.day2;

public interface CIBILScore extends UPI{
	String s="3%"	;
	//Bydeafult-->static final variable	
	public void issuingCard();

}
