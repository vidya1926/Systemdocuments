package week3.day2;

public class AxisBankBranch extends AxisBank{

	public static void main(String[] args) {
		AxisBankBranch sA=new AxisBankBranch();
		sA.activateTraction();
	}

	public void transaction() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void activateTraction() {
		// TODO Auto-generated method stub
		
	}

	public void kycDocument() {
		// TODO Auto-generated method stub
		
	}

	public void rateOfInterest() {
		// TODO Auto-generated method stub
		
	}

	public void cibilScore() {
		// TODO Auto-generated method stub
		
	}

	public void issuingCard() {
		// TODO Auto-generated method stub
		
	}

}
