package week3.day2;

public interface RBI {
	
	//design -->without implementation
	public void kycDocument();
	
	public void rateOfInterest();
	
	public void cibilScore();

}
