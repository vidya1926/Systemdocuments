package week3.day2;

public interface UPI {

	public void transaction();
	
	
}
