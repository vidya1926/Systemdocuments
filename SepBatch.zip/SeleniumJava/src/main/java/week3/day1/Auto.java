package week3.day1;

public class Auto extends Vehicle{

	
	public void noOfWheels() {
		System.out.println("3 Wheels");
	}
	
}
