package week3.day1;

public class ExecutionClass {

	public static void main(String[] args) {
		Car audi=new Car();
		audi.applyBreak();
		audi.startVehicle();
		audi.noOfdoors();
		
		Auto au=new Auto();
		au.applyBreak();
		au.startVehicle();
		au.noOfWheels();

	}

}
