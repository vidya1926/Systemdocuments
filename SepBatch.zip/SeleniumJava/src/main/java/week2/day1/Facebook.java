package week2.day1;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;

public class Facebook {

	public static void main(String[] args) throws IOException {

		
		
	    ChromeOptions options = new ChromeOptions();
	    HashMap<String, Object> ltOptions = new HashMap<String, Object>();
	    options.setPlatformName("Windows 10");
		options.setBrowserVersion("119.0");
		ltOptions.put("username", "vidyar1926");
		ltOptions.put("accessKey", "xqHmrSa12TjL04iSMDva7kF07xB1ElHQWuIjm7u5oa3JJFbXRl");
		ltOptions.put("visual", true);
		ltOptions.put("project", "Leaftaps");
		ltOptions.put("selenium_version", "4.0.0");
		ltOptions.put("w3c", true);
		options.setCapability("LT:Options", ltOptions);
	    options.setEnableDownloads(true);
	    options.addArguments("--enable-managed-downloads");
	 //   ChromeDriver driver = new ChromeDriver(options);
	    URL url = new URL(
				"https://vidyar1926:xqHmrSa12TjL04iSMDva7kF07xB1ElHQWuIjm7u5oa3JJFbXRl@hub.lambdatest.com/wd/hub");
						//username:accesskey@hub.lambdatest.com/wd/hub
		RemoteWebDriver driver = new RemoteWebDriver(url, options);

		/*
		 * List<String> fileNames = new ArrayList<>(); fileNames.add("file_1.txt");
		 * fileNames.add("file_2.jpg");
		 */  driver.get("https://www.selenium.dev/selenium/web/downloads/download.html");
	    driver.findElement(By.id("file-1")).click();
	    driver.findElement(By.id("file-2")).click();	  
	    List<String> files = driver.getDownloadableFiles();

	  //.assertEquals(fileNames, files);
	    String downloadableFile = files.get(0);
	    Path targetDirectory = Files.createTempDirectory("download");

	     driver.downloadFile(downloadableFile, targetDirectory);

	    String fileContent = String.join("", Files.readAllLines(targetDirectory.resolve(downloadableFile)));
	    Assert.assertEquals("Hello, World!", fileContent);

	    //driver.deleteDownloadableFiles();

	//    Assertions.assertTrue(((HasDownloads) driver).getDownloadableFiles().isEmpty());
	  }

}
