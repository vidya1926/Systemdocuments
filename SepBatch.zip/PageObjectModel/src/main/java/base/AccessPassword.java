package base;

public class AccessPassword extends LearnEncapsulation {

	public static void main(String[] args) {
		AccessPassword ap=new AccessPassword();				
		System.out.println(ap.getPwd());
		
		ap.setPwd(2344);		
		System.out.println(ap.getPwd());
		int cwdPwd = ap.getCwdPwd();
		System.out.println(cwdPwd);
		
	}

}
