package base;

import java.io.IOException;

public class Learnfinally {

	public static void main(String[] args) throws IOException {
		
		
		int x=10;
		String s=null;
		int[] arr= {1,2,3,4,5};
		try {
			System.out.println(x/0);
				
		} catch(Exception e){
			System.out.println(e);
		}finally {
		System.out.println("End of Program");
		Runtime.getRuntime().exec("taskkill /im /f chromedriver.exe");
		}
		
	}

}
