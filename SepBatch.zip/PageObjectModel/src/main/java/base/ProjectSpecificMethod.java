package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	// public static ChromeDriver driver;
	private static final ThreadLocal<RemoteWebDriver> tldriver = new ThreadLocal<RemoteWebDriver>();

	// encapsulation
	// getter and setter
	public RemoteWebDriver getDriver() {
		return tldriver.get();
	}

	public void setDriver() {
		tldriver.set(new ChromeDriver());
	}

	public String filename;
	public int sheetIndex;
	  public  ExtentReports extent;
		public String testName, testDesc, author, category;
		public  static ExtentTest test,node;


	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}

	@BeforeClass
	public void testDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}

	public void reportStep(String status, String message) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			node.pass(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		} else if (status.equalsIgnoreCase("fail")) {
			node.fail(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		}

	}

	public int takeSnap() throws IOException {
		int random = (int) (Math.random() * 999);
		File screenshotAs = getDriver().getScreenshotAs(OutputType.FILE);
		File destnfile = new File("./snap/shot" + random + ".jpg");// empty
		FileUtils.copyFile(screenshotAs, destnfile);
		return random;
	}

	@BeforeMethod
	public void preCondition() {
		// driver = new ChromeDriver();
		setDriver();
		getDriver().get("http://leaftaps.com/opentaps/control/login");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	@DataProvider(indices = { 0 })
	public String[][] sendData() throws IOException {
		String[][] data = ReadExcel.readData(filename, sheetIndex);
		return data;
	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

}
