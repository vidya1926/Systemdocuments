package base;

public class LearnEncapsulation {

	
	private int pwd=123;
	
	public void setPwd(int pwd) {
		this.pwd = pwd;
	}

	private int creditPwd() {
		int crdPass=123;
		return crdPass;	
	}
	
	public int getCwdPwd() {
		LearnEncapsulation ob=new LearnEncapsulation();
		int creditPwd = ob.creditPwd();
		return creditPwd;
	}
	
	
	
	public int getPwd() {
		return pwd;
	}
	
	public void name() {
		System.out.println("AccountHolder");
	}
	
	
	
	
	
	public static void main(String[] args) {
		LearnEncapsulation ob=new LearnEncapsulation();
		System.out.println(ob.pwd);
		ob.creditPwd();
	}

}
