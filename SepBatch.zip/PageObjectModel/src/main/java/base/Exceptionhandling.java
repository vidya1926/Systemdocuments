package base;

public class Exceptionhandling {

	public static void main(String[] args) {

		int x = 10;
		String s = null;
		int[] arr = { 1, 2, 3, 4, 5 };
		try {
			System.out.println(x / 1);
			System.out.println(arr[6]);
		} catch (ArithmeticException e) {
			System.out.println(x / 1);
			System.out.println(e);
		} catch (NullPointerException n) {
			System.out.println("Check your input " + n);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("End of Program");

	}

}
