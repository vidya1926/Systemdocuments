package testcase;

import base.ProjectSpecificMethod;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features= {"src/main/java/feature/TC001_Login.feature"}
,glue="pages",monochrome=true)
public class Runner extends ProjectSpecificMethod{

}
