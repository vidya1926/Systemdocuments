package testcase;

import java.io.IOException;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class LogoutFuntionality extends ProjectSpecificMethod {

	@Test
	public void runLogout() throws IOException {

		/**
		 * LoginPage lp=new LoginPage(); lp.enterUsername(); lp.enterPassword();
		 * 
		 * WelcomePage wp= new WelcomePage(); wp.clickCrmsfa();
		 */
		new LoginPage().enterUsername().enterPassword().clickLogin().clickLogout();

	}

}
