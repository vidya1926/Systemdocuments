package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class Loginfunctionality extends ProjectSpecificMethod{
	
	
	@BeforeTest
	public void setValues() {
		testName = "Login Functionality";
		testDesc = "Login with Positive Credentials";
		author = "Mythili";
		category = "Funtional";
	}
		
	@Test
	public void runLogin() throws IOException {
				
		System.out.println(getDriver());

		/*
		 * LoginPage lp=new LoginPage(); lp.enterUsername(); lp.enterPassword();
		 * 
		 * 
		 * WelcomePage wp= new WelcomePage(); wp.clickCrmsfa();
		 */
		
		new LoginPage().enterUsername().enterPassword().clickLogin().clickCrmsfa();
		
	}

}
