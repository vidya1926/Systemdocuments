package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Then;

public class WelcomePage extends ProjectSpecificMethod {
	/*
	 * public WelcomePage(ChromeDriver driver) { this.driver = driver; }
	 */
	@Then("WelcomePage is displayed")
	public WelcomePage verifyCrmsfa() {
		System.out.println(getDriver().getTitle());
		return this;
	}

	public MyHomePage clickCrmsfa() throws IOException {
		try {
			getDriver().findElement(By.linkText("CRM/SFA")).click();
			reportStep("Pass","CRMSFA is Clicked Successfully");

		} catch (Exception e) {
			reportStep("Fail","CRMSFA is not Clicked Successfully");
		}
		return new MyHomePage();
	}

	public LoginPage clickLogout() {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		return new LoginPage();
	}

}
