package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class LeadsPage extends ProjectSpecificMethod{
	
	/*
	 * public LeadsPage(ChromeDriver driver) { this.driver=driver; }
	 */
	public CreateLeadPage clickcreateLead() throws IOException {
		try {
			getDriver().findElement(By.linkText("Create Lead")).click();
			reportStep("Pass","Create lead is Clicked Successfully");

		} catch (Exception e) {
			reportStep("Fail","Create lead is not Clicked Successfully");

		}
		return new CreateLeadPage();
	}
	
	
	
	public Findleads clickfindsLead() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new Findleads();
	}
	
	

}
