package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class MyHomePage extends ProjectSpecificMethod {

	/*
	 * public MyHomePage() { this.driver=driver; }
	 */
	public LeadsPage clickLeads() throws IOException {
		try {
			getDriver().findElement(By.linkText("Leads")).click();
			reportStep("Pass", "Leads is Clicked Successfully");

		} catch (Exception e) {
			reportStep("Fail", "Leads  is not Clicked Successfully");
		}
		return new LeadsPage();
	}

	public AccountsPage clickAccounts() {
		getDriver().findElement(By.linkText("Leads")).click();
		return new AccountsPage();
	}

}
