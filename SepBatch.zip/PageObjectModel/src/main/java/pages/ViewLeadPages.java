package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewLeadPages extends ProjectSpecificMethod{

	
	/*
	 * public ViewLeadPages(ChromeDriver driver) { this.driver=driver; }
	 */
	
	
	public ViewLeadPages verifyCreateLead() throws IOException {
		try {
			System.out.println(getDriver().getTitle());
			reportStep("Pass","Verified the title");

		} catch (Exception e) {
			reportStep("Fail","Verification is not successful");

		}
		return this;
	}
}
