package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class CreateLeadPage extends ProjectSpecificMethod {

	/*
	 * public CreateLeadPage(ChromeDriver driver) { this.driver = driver; }
	 */

	public CreateLeadPage enterCompanyName(String cname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_companyNam")).sendKeys(cname);
			reportStep("Pass", "Companyname is entered Successfully");

		} catch (Exception e) {
			reportStep("Fail", "Companyname is not entered Successfully");
		}
		return this;
	}

	public CreateLeadPage enterFirstName(String fname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fname);
			reportStep("Pass", "Firstname is entered Successfully");

		} catch (Exception e) {
			reportStep("Fail", "Firstname is not entered Successfully");

		}
		return this;
	}

	public CreateLeadPage enterLastName(String lname) throws IOException {
		try {
			getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lname);
			reportStep("Pass", "Lastname is entered Successfully");

		} catch (Exception e) {
			reportStep("Fail", "LastName is not entered Successfully");

		}
		return this;
	}

	public ViewLeadPages clickCreate() throws IOException {

		try {
			getDriver().findElement(By.name("submitButton")).click();
			reportStep("Pass", "Create button is clicked Successfully");

		} catch (Exception e) {
			reportStep("Fail", "Create button is not entered Successfully");
		}
		return new ViewLeadPages();
	}

}
