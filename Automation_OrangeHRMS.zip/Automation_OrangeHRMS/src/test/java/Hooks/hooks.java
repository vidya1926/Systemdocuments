package Hooks;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;



import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import steps.BaseClass;

public class hooks extends BaseClass{

	@Before
	public void before(Scenario sc) {
		name = sc.getName();
		
	}
}
